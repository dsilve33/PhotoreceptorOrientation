%% Clear figures and command window only 
close all;
clc;

%% Load workspace and open image figure file

% Enter identifiers
Eye='Eye1';
Genotype='C57BL6J';
LDcycle='Dark-reared';
RetinalRegion = 3;
RetinalRegionChar = num2str(RetinalRegion);

figurefile=fullfile(Genotype,LDcycle,Eye,RetinalRegionChar,[Genotype LDcycle Eye RetinalRegionChar '_Region.fig']);;

open(figurefile);

%% Point to rod inner segment tips and bases in each region
%IS Tip Region1, Rods 1 2 and 3
rodtips1xyposition = [];
for i=1:3;
rodtips1 = drawpoint;
rodtips1position = [rodtips1.Position];
rodtips1xyposition = [rodtips1xyposition; rodtips1position];
end

%IS Base Region1, Rods 1 2 and 3
rodbases1xyposition = [];
for i=1:3;
rodbases1 = drawpoint;
rodbases1position = [rodbases1.Position];
rodbases1xyposition = [rodbases1xyposition; rodbases1position];
end


%% Draw lines from inner segment tips to eye center, point C

%IS Tip-to-Center Region1, Rods 1 2 and 3
ISTtoC_lines1xyposition = [];
for i = 1:length(rodtips1xyposition(:,1))
    ISTtoC_lines1 = drawline('Color','b','Position',[rodtips1xyposition(i,1) rodtips1xyposition(i,2); EyeCenterPosition],'Visible','on') 
    ISTtoC_lines1position = [ISTtoC_lines1.Position];
    ISTtoC_lines1xyposition = [ISTtoC_lines1xyposition; ISTtoC_lines1position];
end;

% Make cell array for use with polyfit
N = 2;
S = size(ISTtoC_lines1xyposition);
R = N*ones(1,ceil(S(1)/N)); % number of rows in each cell.
R(end) = 1+mod(S(1)-1,N); % number of rows in last cell.
M1_1cell = mat2cell(ISTtoC_lines1xyposition,R,S(2));
M1a1 = cell2mat(M1_1cell(1));
M1b1 = cell2mat(M1_1cell(2));
M1c1 = cell2mat(M1_1cell(3));

%% Draw lines from inner segment tips to inner segment base, line IST to ISB
%Region 1, Rods 1 2 and 3
ISTtoISB_1ines1xyposition = [];
for i = 1:length(rodtips1xyposition(:,1))
    rodnumber = num2str(i);
    ISTtoISB_lines1 = drawline('Color','m','Position',[rodtips1xyposition(i,1) rodtips1xyposition(i,2); rodbases1xyposition(i,1) rodbases1xyposition(i,2)],'Label',(rodnumber)) %draw line from center to right edge of retina
    ISTtoISB_lines1position = [ISTtoISB_lines1.Position];
    ISTtoISB_1ines1xyposition = [ISTtoISB_1ines1xyposition; ISTtoISB_lines1position];
end;

% Make cell array for use with polyfit
N = 2;
S = size(ISTtoISB_1ines1xyposition);
R = N*ones(1,ceil(S(1)/N)); % number of rows in each cell.
R(end) = 1+mod(S(1)-1,N); % number of rows in last cell.
M1_2cell = mat2cell(ISTtoISB_1ines1xyposition,R,S(2));
M1a2 = cell2mat(M1_2cell(1))
M1b2 = cell2mat(M1_2cell(2))
M1c2 = cell2mat(M1_2cell(3))

promptMessage = sprintf('Do you want to Continue processing,\nor Cancel to abort processing?');
button = questdlg(promptMessage, 'Continue', 'Continue', 'Cancel', 'Continue');
if strcmpi(button, 'Cancel')
  return; % Or break or continue
end

saveas(figure(1),fullfile(Genotype,LDcycle,Eye,RetinalRegionChar,[Genotype LDcycle Eye RetinalRegionChar '_OSIS_Region']),'fig') %Save Individual Region

saveas(figure(1),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLRegions']),'fig') %Save All Regions

%%% Extend line towards pupil to determine focal point of rods
%
%figure2file=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLProjections' '.fig']);;
%open(figure2file);
%for i = 1:length(rodtips1xyposition(:,1))
%    foldextension = 1000;
%    V = [rodbases1xyposition(i,1) rodbases1xyposition(i,2)] - [rodtips1xyposition(i,1) rodtips1xyposition(i,2)];
%    pto1 = [rodtips1xyposition(i,1) rodtips1xyposition(i,2)];   
%    pto2 = [rodbases1xyposition(i,1) rodbases1xyposition(i,2)];
%    pto3 = [pto2 - pto1];
%    pto4 = [pto2 + foldextension.*pto3];
%    rodnumber = num2str(i);
%    ISTtoISB_lines1 = drawline('Color','g','Position',[pto1;pto4]) %draw line from center to right edge of retina
%end;
%
%% Redraw rod inner segments for comparison
%for i = 1:length(rodtips1xyposition(:,1))
%    ISTtoISB_lines1 = drawline('Color','m','Position',[rodtips1xyposition(i,1) rodtips1xyposition(i,2); rodbases1xyposition(i,1) rodbases1xyposition(i,2)]) %draw line from center to right edge of retina
%end;
%
%PupilCenter = drawpoint('Position',PupilCenterPosition);
%PupilCenter.Label = 'P';
%PupilCenter.Color = 'r';
%EyeCenterPosition = EyeMeasurements(1).Centroid;
%EyeCenter = drawpoint('Position',EyeCenterPosition);
%EyeCenter.Label = 'C';
%EyeCenter.Color = 'r';

%saveas(figure(2),fullfile(Genotype,LDcycle,Eye,RetinalRegionChar,[Genotype LDcycle Eye RetinalRegionChar '_OSIS_Projections']),'fig') %Save Individual Projections

%saveas(figure(2),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLProjections']),'fig') %Save All Projections

%% Measure angle between vector1: (inner segment tip)-to-(eye center) and vector2: (inner segment tip)-to-(inner segment base)
%% Region 1 Rod 1 /IST-to-C angle
ISTtoC_lines1_Region1Rod1 = polyfit([M1a1(:,1)],[M1a1(:,2)],1);
ISTtoISB_lines1_RegionRod1 = polyfit([M1a2(:,1)],[M1a2(:,2)],1);

vect1a1 = [1 ISTtoC_lines1_Region1Rod1(1)]; % create a vector based on the line equation
vect1a2 = [1 ISTtoISB_lines1_RegionRod1(1)];
dp1a = dot(vect1a1, vect1a2);

% compute vector lengths
length1a1 = sqrt(sum(vect1a1.^2));
length1a2 = sqrt(sum(vect1a2.^2));

% obtain angle of intersection in radians
angleone_1a_radians = acos(dp1a/(length1a1*length1a2));
angleone_1a_degrees = angleone_1a_radians*(180/pi);
if angleone_1a_degrees > 90;
    angleone_1a_degrees = 180 - angleone_1a_degrees;
else
    angleone_1a_degrees = angleone_1a_degrees;
end


%% Region 1 Rod 2 IST-to-C angle
ISTtoC_lines1_Region1Rod2 = polyfit([M1b1(:,1)],[M1b1(:,2)],1);
ISTtoISB_lines1_Region1Rod2 = polyfit([M1b2(:,1)],[M1b2(:,2)],1);

vect1b1 = [1 ISTtoC_lines1_Region1Rod2(1)]; % create a vector based on the line equation
vect1b2 = [1 ISTtoISB_lines1_Region1Rod2(1)];
dp1b = dot(vect1b1, vect1b2);

% compute vector lengths
length1b1 = sqrt(sum(vect1b1.^2));
length1b2 = sqrt(sum(vect1b2.^2));

% obtain angle of intersection in radians
angleone_1b_radians = acos(dp1b/(length1b1*length1b2));
angleone_1b_degrees = angleone_1b_radians*(180/pi);
if angleone_1b_degrees > 90;
    angleone_1b_degrees = 180 - angleone_1b_degrees;
else
    angleone_1b_degrees = angleone_1b_degrees;
end

%% Region 1 Rod 3 IST-to-C angle
ISTtoC_lines1_Region1Rod3 = polyfit([M1c1(:,1)],[M1c1(:,2)],1);
ISTtoISB_lines1_Region1Rod3 = polyfit([M1c2(:,1)],[M1c2(:,2)],1);

vect1c1 = [1 ISTtoC_lines1_Region1Rod3(1)]; % create a vector based on the line equation
vect1c2 = [1 ISTtoISB_lines1_Region1Rod3(1)];
dp1c = dot(vect1c1, vect1c2);

% compute vector lengths
length1c1 = sqrt(sum(vect1c1.^2));
length1c2 = sqrt(sum(vect1c2.^2));

% obtain angle of intersection in radians
angleone_1c_radians = acos(dp1c/(length1c1*length1c2));
angleone_1c_degrees = angleone_1c_radians*(180/pi);
if angleone_1c_degrees > 90;
    angleone_1c_degrees = 180 - angleone_1c_degrees;
else
    angleone_1c_degrees = angleone_1c_degrees;
end

%% Collected results for this region: Vectors (IST-to-C) and (IST-to-ISB)
Region1AngleOneDegrees = [angleone_1a_degrees ; angleone_1b_degrees ; angleone_1c_degrees]; %Double-check by eye
IS_MeanRegion1AngleOneDegrees = mean(Region1AngleOneDegrees);
IS_SDRegion1AngleOneDegrees = std(Region1AngleOneDegrees);

%% Collected Results Table.  This is for the remaining regions.
ISarrayone={Genotype,LDcycle,Eye,RetinalRegion,IS_MeanRegion1AngleOneDegrees,IS_SDRegion1AngleOneDegrees,angleone_1a_degrees,angleone_1b_degrees,angleone_1c_degrees};
ISTableOneA=cell2table(ISarrayone);
%Set variable types
tablefile=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedISTableOnePoints.txt'])
opts=detectImportOptions(tablefile);
opts=setvartype(opts,{'ISarrayone1'},'char');
opts=setvartype(opts,{'ISarrayone2'},'char');
opts=setvartype(opts,{'ISarrayone3'},'char');
opts=setvartype(opts,{'ISarrayone4','ISarrayone5','ISarrayone6','ISarrayone7','ISarrayone7','ISarrayone8','ISarrayone9'},'double');
ISTableOne=readtable(tablefile,opts);
UpdatedISTableOnePoints=[ISTableOne; ISTableOneA];
UpdatedISTableOne=UpdatedISTableOnePoints;
writetable(UpdatedISTableOnePoints,fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedISTableOnePoints.txt']));
%Modify variable names T
UpdatedISTableOne.Properties.VariableNames = {'Genotype' 'LDcycle' 'Eye' 'RetinalRegion' 'IS_MeanRegion1AngleOneDegrees' 'IS_SDRegion1AngleOneDegrees' 'angleone_1a_degrees' 'angleone_1b_degrees' 'angleone_1c_degrees'};
writetable(UpdatedISTableOne,fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedISTableOne.txt']));
UpdatedISTableOne