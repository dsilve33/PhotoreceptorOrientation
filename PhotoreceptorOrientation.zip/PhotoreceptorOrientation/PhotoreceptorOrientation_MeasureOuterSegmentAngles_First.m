%% Clear workspace 
close all;
clear all;
clc;

%% Load workspace and open image figure file

% Enter identifiers
Eye='Eye1';
Genotype='C57BL6J';
LDcycle='Dark-reared';
RetinalRegion = -3;
RetinalRegionChar = num2str(RetinalRegion);

workspace=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'Workspace' '.mat']);
figurefile=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'Image3' '.fig']);

load(workspace);

close all;

open(figurefile); 

% Make new folder to save image files from analysis
mkdir(fullfile(Genotype,LDcycle,Eye,RetinalRegionChar));

%% Step 1: Zoom in and click on 3 rod outer segment tips. 

%OS Tip Region1, Rods 1 2 and 3
rodtips1xyposition = [];
for i=1:3;
rodtips1 = drawpoint;
rodtips1position = [rodtips1.Position];
rodtips1xyposition = [rodtips1xyposition; rodtips1position];
end

%% Step 2: Click on the 3 respective outer segment bases.

%OS Base Region1, Rods 1 2 and 3
rodbases1xyposition = [];
for i=1:3;
rodbases1 = drawpoint;
rodbases1position = [rodbases1.Position];
rodbases1xyposition = [rodbases1xyposition; rodbases1position];
end


%% Draw lines from outer segment tips to eye center, point C

%OS Tip-to-Center Region1, Rods 1 2 and 3
OSTtoC_lines1xyposition = [];
for i = 1:length(rodtips1xyposition(:,1))
    OSTtoC_lines1 = drawline('Color','b','Position', [rodtips1xyposition(i,1) rodtips1xyposition(i,2); EyeCenterPosition]) 
    OSTtoC_lines1position = [OSTtoC_lines1.Position];
    OSTtoC_lines1xyposition = [OSTtoC_lines1xyposition; OSTtoC_lines1position];
end;

% Make cell array for use with polyfit
N = 2;
S = size(OSTtoC_lines1xyposition);
R = N*ones(1,ceil(S(1)/N)); % number of rows in each cell.
R(end) = 1+mod(S(1)-1,N); % number of rows in last cell.
M1_1cell = mat2cell(OSTtoC_lines1xyposition,R,S(2));
M1a1 = cell2mat(M1_1cell(1));
M1b1 = cell2mat(M1_1cell(2));
M1c1 = cell2mat(M1_1cell(3));

%% Draw lines from outer segment tips to outer segment base, line OST to OSB
%Region 1, Rods 1 2 and 3
OSTtoOSB_1ines1xyposition = [];
for i = 1:length(rodtips1xyposition(:,1))
    rodnumber = num2str(i);
    OSTtoOSB_lines1 = drawline('Color','r','Position',[rodtips1xyposition(i,1) rodtips1xyposition(i,2); rodbases1xyposition(i,1) rodbases1xyposition(i,2)],'Label',(rodnumber)) %draw line from center to right edge of retina
    OSTtoOSB_lines1position = [OSTtoOSB_lines1.Position];
    OSTtoOSB_1ines1xyposition = [OSTtoOSB_1ines1xyposition; OSTtoOSB_lines1position];
end;

% Make cell array for use with polyfit
N = 2;
S = size(OSTtoOSB_1ines1xyposition);
R = N*ones(1,ceil(S(1)/N)); % number of rows in each cell.
R(end) = 1+mod(S(1)-1,N); % number of rows in last cell.
M1_2cell = mat2cell(OSTtoOSB_1ines1xyposition,R,S(2));
M1a2 = cell2mat(M1_2cell(1))
M1b2 = cell2mat(M1_2cell(2))
M1c2 = cell2mat(M1_2cell(3))

promptMessage = sprintf('Do you want to Continue processing,\nor Cancel to abort processing?');
button = questdlg(promptMessage, 'Continue', 'Continue', 'Cancel', 'Continue');
if strcmpi(button, 'Cancel')
  return; % Or break or continue
end

saveas(figure(1),fullfile(Genotype,LDcycle,Eye,RetinalRegionChar,[Genotype LDcycle Eye RetinalRegionChar '_Region']),'fig') %Save Individual Region

saveas(figure(1),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLRegions']),'fig') %Save All Regions

%%% Extend line towards pupil to determine focal point of rods
%%Maximize figure window
%figure2 = figure('WindowState','maximized',...
%    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
%% Create axes for maximized figure.
%axes1 = axes('Parent',figure2,...
%    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
%axis off
%hold(axes1,'on');
%
%figure(2), imshow(Ione);
%for i = 1:length(rodtips1xyposition(:,1))
%    foldextension = 1000;
%    V = [rodbases1xyposition(i,1) rodbases1xyposition(i,2)] - [rodtips1xyposition(i,1) rodtips1xyposition(i,2)];
%    pto1 = [rodtips1xyposition(i,1) rodtips1xyposition(i,2)];   
%    pto2 = [rodbases1xyposition(i,1) rodbases1xyposition(i,2)];
%    pto3 = [pto2 - pto1];
%    pto4 = [pto2 + foldextension.*pto3];
%    OSTtoOSB_lines1 = drawline('Color','y','Position',[pto1;pto4]) %draw line from center to right edge of retina
%end;

%% Redraw rod outer segments for comparison
%for i = 1:length(rodtips1xyposition(:,1))
%    OSTtoOSB_lines1 = drawline('Color','r','Position',[rodtips1xyposition(i,1) rodtips1xyposition(i,2); rodbases1xyposition(i,1) rodbases1xyposition(i,2)]) %draw line from center to right edge of retina
%end;

%PupilCenter = drawpoint('Position',PupilCenterPosition);
%PupilCenter.Label = 'P';
%PupilCenter.Color = 'r';
%EyeCenterPosition = EyeMeasurements(1).Centroid;
%EyeCenter = drawpoint('Position',EyeCenterPosition);
%EyeCenter.Label = 'C';
%EyeCenter.Color = 'r';

%saveas(figure(2),fullfile(Genotype,LDcycle,Eye,RetinalRegionChar,[Genotype LDcycle Eye RetinalRegionChar '_Projections']),'fig') %Save Individual Projections

%saveas(figure(2),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLProjections']),'fig') %Save All Projections

%% Measure angle between vector1: (outer segment tip)-to-(eye center) and vector2: (outer segment tip)-to-(outer segment base)
%% Region 1 Rod 1 OST-to-C angle
OSTtoC_lines1_Region1Rod1 = polyfit([M1a1(:,1)],[M1a1(:,2)],1);
OSTtoOSB_lines1_RegionRod1 = polyfit([M1a2(:,1)],[M1a2(:,2)],1);

vect1a1 = [1 OSTtoC_lines1_Region1Rod1(1)]; % create a vector based on the line equation
vect1a2 = [1 OSTtoOSB_lines1_RegionRod1(1)];
dp1a = dot(vect1a1, vect1a2);

% compute vector lengths
length1a1 = sqrt(sum(vect1a1.^2));
length1a2 = sqrt(sum(vect1a2.^2));

% obtain angle of intersection in radians
angleone_1a_radians = acos(dp1a/(length1a1*length1a2));
angleone_1a_degrees = angleone_1a_radians*(180/pi);
if angleone_1a_degrees > 90;
    angleone_1a_degrees = 180 - angleone_1a_degrees;
else
    angleone_1a_degrees = angleone_1a_degrees;
end

%% Region 1 Rod 2 OST-to-C angle
OSTtoC_lines1_Region1Rod2 = polyfit([M1b1(:,1)],[M1b1(:,2)],1);
OSTtoOSB_lines1_Region1Rod2 = polyfit([M1b2(:,1)],[M1b2(:,2)],1);

vect1b1 = [1 OSTtoC_lines1_Region1Rod2(1)]; % create a vector based on the line equation
vect1b2 = [1 OSTtoOSB_lines1_Region1Rod2(1)];
dp1b = dot(vect1b1, vect1b2);

% compute vector lengths
length1b1 = sqrt(sum(vect1b1.^2));
length1b2 = sqrt(sum(vect1b2.^2));

% obtain angle of intersection in radians
angleone_1b_radians = acos(dp1b/(length1b1*length1b2));
angleone_1b_degrees = angleone_1b_radians*(180/pi);
if angleone_1b_degrees > 90;
    angleone_1b_degrees = 180 - angleone_1b_degrees;
else
    angleone_1b_degrees = angleone_1b_degrees;
end

%% Region 1 Rod 3 OST-to-C angle
OSTtoC_lines1_Region1Rod3 = polyfit([M1c1(:,1)],[M1c1(:,2)],1);
OSTtoOSB_lines1_Region1Rod3 = polyfit([M1c2(:,1)],[M1c2(:,2)],1);

vect1c1 = [1 OSTtoC_lines1_Region1Rod3(1)]; % create a vector based on the line equation
vect1c2 = [1 OSTtoOSB_lines1_Region1Rod3(1)];
dp1c = dot(vect1c1, vect1c2);

% compute vector lengths
length1c1 = sqrt(sum(vect1c1.^2));
length1c2 = sqrt(sum(vect1c2.^2));

% obtain angle of intersection in radians
angleone_1c_radians = acos(dp1c/(length1c1*length1c2));
angleone_1c_degrees = angleone_1c_radians*(180/pi);
if angleone_1c_degrees > 90;
    angleone_1c_degrees = 180 - angleone_1c_degrees;
else
    angleone_1c_degrees = angleone_1c_degrees;
end

%% Collected results for this region: Vectors (OST-to-C) and (OST-to-OSB)
Region1AngleOneDegrees = [angleone_1a_degrees ; angleone_1b_degrees ; angleone_1c_degrees]; %Double-check by eye
OS_MeanRegion1AngleOneDegrees = mean(Region1AngleOneDegrees);
OS_SDRegion1AngleOneDegrees = std(Region1AngleOneDegrees);

%% Collected Results Table.  This is for the first cell.
%%Comment out this section after first cell.
OSarrayone={Genotype,LDcycle,Eye,RetinalRegion,OS_MeanRegion1AngleOneDegrees,OS_SDRegion1AngleOneDegrees,angleone_1a_degrees,angleone_1b_degrees,angleone_1c_degrees};
OSTableOneA=cell2table(OSarrayone)
%Set variable types
opts=detectImportOptions('OSTableOne.txt');
opts=setvartype(opts,{'OSarrayone1'},'char');
opts=setvartype(opts,{'OSarrayone2'},'char');
opts=setvartype(opts,{'OSarrayone3'},'char');
opts=setvartype(opts,{'OSarrayone4','OSarrayone5','OSarrayone6','OSarrayone7','OSarrayone7','OSarrayone8','OSarrayone9'},'double');
OSTableOne=readtable('OSTableOne.txt',opts);
UpdatedOSTableOnePoints=[OSTableOne; OSTableOneA];
UpdatedOSTableOnePoints(1,:)=[];
UpdatedOSTableOne=UpdatedOSTableOnePoints;
writetable(UpdatedOSTableOnePoints,fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedOSTableOnePoints.txt']));
%Modify variable names T
UpdatedOSTableOne.Properties.VariableNames = {'Genotype' 'LDcycle' 'Eye' 'RetinalRegion' 'OS_MeanRegion1AngleOneDegrees' 'OS_SDRegion1AngleOneDegrees' 'angleone_1a_degrees' 'angleone_1b_degrees' 'angleone_1c_degrees'};
writetable(UpdatedOSTableOne,fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedOSTableOne.txt']));
UpdatedOSTableOne