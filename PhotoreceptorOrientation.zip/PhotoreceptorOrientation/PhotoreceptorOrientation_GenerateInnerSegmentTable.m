% Generate data table for storing photoreceptor orientation data
Eye = [];
Genotype = [];
LDcycle = [];
RetinalRegion = [];
IS_MeanRegion1AngleOneDegrees = [];
IS_SDRegion1AngleOneDegrees = [];
angleone_1a_degrees = [];
angleone_1b_degrees = [];
angleone_1c_degrees = [];
ISarrayone={Eye,Genotype,LDcycle,RetinalRegion,IS_MeanRegion1AngleOneDegrees,IS_SDRegion1AngleOneDegrees,angleone_1a_degrees,angleone_1b_degrees,angleone_1c_degrees
};
ISTableOne=cell2table(ISarrayone)

writetable(ISTableOne,'ISTableOne.txt');

