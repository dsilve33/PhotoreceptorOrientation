% Generate data table for storing photoreceptor orientation data
Eye = [];
Genotype = [];
LDcycle = [];
RetinalRegion = [];
OS_MeanRegion1AngleOneDegrees = [];
OS_SDRegion1AngleOneDegrees = [];
angleone_1a_degrees = [];
angleone_1b_degrees = [];
angleone_1c_degrees = [];
OSarrayone={Eye,Genotype,LDcycle,RetinalRegion,OS_MeanRegion1AngleOneDegrees,OS_SDRegion1AngleOneDegrees,angleone_1a_degrees,angleone_1b_degrees,angleone_1c_degrees
};
OSTableOne=cell2table(OSarrayone)

writetable(OSTableOne,'OSTableOne.txt');

