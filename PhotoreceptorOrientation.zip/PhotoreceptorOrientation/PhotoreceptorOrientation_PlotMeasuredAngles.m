close all;
clc;

% Enter identifiers
Eye='Eye1';
Genotype='C57BL6J';
LDcycle='Dark-reared';

OStablefile=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedOSTableOnePoints.txt']);
IStablefile=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'UpdatedISTableOnePoints.txt']);

UpdatedOSTableOne=readtable(OStablefile)
OSRegion = table2array(UpdatedOSTableOne(:,4));
MeanOSRegion1AngleOneDegrees = table2array(UpdatedOSTableOne(:,5));
SDOSRegion1AngleOneDegrees = table2array(UpdatedOSTableOne(:,6));

UpdatedISTableOne=readtable(IStablefile)
ISRegion = table2array(UpdatedISTableOne(:,4));
MeanISRegion1AngleOneDegrees = table2array(UpdatedISTableOne(:,5));
SDISRegion1AngleOneDegrees = table2array(UpdatedISTableOne(:,6));

figurefile=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLRegions.fig']);;
open(figurefile);

%figure2file=fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'ALLProjections.fig']);;
%open(figure2file);

% Create Plots
% Maximize figure.
figure2 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure2,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

figure(2)
subplot1 = subplot(2,1,1,'Parent',figure2);
hold(subplot1,'on');
 xlim(subplot1,[-3.2 3.2]);
 ylim(subplot1,[0 60]);
box(subplot1,'off');

% Create errorbar
errorbar(OSRegion,MeanOSRegion1AngleOneDegrees,SDOSRegion1AngleOneDegrees,'Parent',subplot1,'MarkerSize',5,...
    'MarkerFaceColor',[0 0 0],...
    'MarkerEdgeColor',[0 0 0],...
    'Marker','square',...
    'CapSize',5,...
    'Color',[0 0 0]);

% Create ylabel
ylabel({'Angle 1 (OST-to-C and OST-to-OSB)'});
% Create xlabel
xlabel({'Retinal Region'}) 

% Create subplot
subplot2 = subplot(2,1,2,'Parent',figure2);
hold(subplot2,'on');
 xlim(subplot2,[-3.2 3.2]);
 ylim(subplot2,[0 60]);
 box(subplot2,'off');

% Create errorbar
errorbar(ISRegion,MeanISRegion1AngleOneDegrees,SDISRegion1AngleOneDegrees,'Parent',subplot2,'MarkerSize',5,...
    'MarkerFaceColor',[0 0 0],...
    'MarkerEdgeColor',[0 0 0],...
    'Marker','square',...
    'CapSize',5,...
    'Color',[0 0 0]);

% Create ylabel
ylabel({'Angle 2 (IST-to-C and IST-to-ISB)'});
% Create xlabel
xlabel({'Retinal Region'}) 


