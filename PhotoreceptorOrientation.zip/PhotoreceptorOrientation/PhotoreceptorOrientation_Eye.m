%%% Written by Daniel Silverman and last checked on September 26, 2020.
%%% 
%%% This program was written based on the Image Segmentation Tutorial found
%%% at https://www.mathworks.com/matlabcentral/fileexchange/25157-image-segmentation-tutorial
%%% 
%%% This program is used to locate the approximate center of a
%%% cross-sectional image of a mouse eye as well as to identify its approximate pupil
%%% center and to define 7 sectors of the retina.
%%%
%%% This program will save a processed image for measurement of angles
%%% between photoreceptor outer segments and inner segments relative to the
%%% eye's center point.

%% Clear workspace 
close all;
clear all;
clc;

%% Enter identifiers
Genotype ='C57BL6J'; % Enter details about rearing, genotype, and age
LDcycle ='Dark-reared'; % Enter location where mouse was housed
Eye ='Eye1'; % Enter label for eye
rotationangle = 90; % Rotate eye to point towards lower right corner for consistency across images
value = (pi/6); % Approximate angle of the retina beyond pi
threshold = 150; % Set threshold intensity above which pixels become 1 and below which, pixels become 0.  May need to try a few different values after seeing pixel intensity histrogram.
filename = 'Dark-reared.tif'; % Enter filename of the image and include file path if image is not in same folder as PhotoreceptorOrientation_EYE.m

mkdir(fullfile(Genotype,LDcycle,Eye)); % Make new folder to save image files from analysis


%% Step 1: Read and Display Image
Ione = imread(filename); % Read image file
Ione = rgb2gray(Ione); % Convert RGB image to grayscale for analysis
[rows, columns, numberOfColorChannels] = size(Ione); % Determine number of pixels and color channels (should be 1 for grayscale)

% Maximize figure window for easy viewing.
figure1 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);

% Create axes for maximized figure.
axes1 = axes('Parent',figure1,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off;
hold(axes1,'on');

%% Step 2: Crop image to remove border
Ione = imshow(Ione); % Display image
promptMessage = sprintf('Crop image near perimeter of the eye by: 1) Drawing a rectangle surrounding the eye and 2) Double clicking within the drawn rectangle.');
title(promptMessage, 'FontSize', 12);
Ione = imcrop(Ione); % Crop image near the eye border to avoid image border or debris being recognized as an edge
uicontrol('Style', 'Edit', 'String', 'My edit box','TooltipString', 'My tooltip');
Ione = imrotate(Ione,rotationangle); % Rotate image to position pupil center facing the lower right corner of the image
figure(2), imshow(Ione); % Display cropped and rotated image

% Maximize figure window.
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
drawnow;
axis image; % Make sure image is not artificially stretched because of screen's aspect ratio.

%% Step 3: Plot pixel-intensity histogram and Set threshold value
% Maximize figure for easy viewing.
figure3 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure3,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
hold(axes1,'on');

[pixelCount, grayLevels] = imhist(Ione); % Plot intensity histogram to determine best threshold value to generate a binary image.

figure(3), bar(pixelCount); % Plot intensity histogram 

xlim([0 grayLevels(end)]); % Scale x axis manually

ylabel('Pixel Count', 'FontSize', 18);
xlabel('Grayscale Pixel intensity', 'FontSize', 18);

thresholdValue = threshold; % Set threshold above which pixels become 1 and below which, pixels become 0.  May need to try a few different values.

hold on; % Keep histogram in plot

maxYValue = ylim; % Set y axis manually

line([thresholdValue, thresholdValue], maxYValue, 'Color', 'r'); % Plot threshold as a vertical red bar on the histogram.

%% Step 4: Generate binary image.
binaryImage = Ione > thresholdValue; % Threshold the image to get a binary image (only 0's and 1's) of class "logical." High Intensity objects will be chosen if you use >.

binaryImage = imfill(binaryImage, 'holes'); % Perform a "hole fill" to get rid of any background pixels or "holes" inside the image objects.

% Maximize figure for easy viewing.
figure4 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure4,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

figure(4),imshow(binaryImage); % Display FILLED binary image. 

%% Step 5: Trace edges of binary image and fill objects within the edges.
%Maximize figure window for easy viewing
figure5 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure5,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

% Trace edges of binary image
figure(5), imshow(binaryImage); % Display binary image
[~,threshold] = edge(binaryImage,'sobel'); % Find edges in binary image
binaryImageedge = edge(binaryImage,'sobel',threshold); 
imshow(binaryImageedge) % Display binary image with edges traced

% "Dilate" edge lines to connect neighboring points along edges.
se90 = strel('line',60,90); 
se0 = strel('line',60,0);
Ioneedgedil = imdilate(binaryImageedge,[se90 se0]);
figure(5), imshow(Ioneedgedil)

% Fill objects within image edges.
Ioneedgedfill = imfill(Ioneedgedil,'holes');
figure(5), imshow(Ioneedgedfill)

%% Step 6: Identify individual objects by seeing which pixels are connected to each other.
% Each group of connected pixels will be given a label, a number, to identify it and distinguish it from the other objects.
% Perform connected components labeling with either bwlabel() or bwconncomp().
labeledImage = bwlabel(Ioneedgedfill, 8); % Label each object so we can make measurements of it. If everything above works properly, the eye should be the only object. However, occasionally there may be smaller objects from debris surrounding the eye. The code will identify extraneous objects and remove them to focus on analyzing the eye.

%Maximize figure window for easy viewing
figure6 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure6,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

% labeledImage is an integer-valued image where all pixels in the objects have values of 1, or 2, or 3, or ... etc.
figure(6),imshow(labeledImage, []);  % Show the gray scale image.

%% Step 7: Get all object properties. This step should take ~6 sec.
tic; %Start timer

EyeMeasurements = regionprops(labeledImage, Ione, 'Centroid','Area','Perimeter','EquivDiameter'); % 1) Identify centroid of eye, and 2) calculate area, perimeter, and approximate diameter.
numberOfObjects = size(EyeMeasurements, 1);

elapsedtime1 = toc; %Stop timer and record elapsed time

%% Step 8: Plot borders around all objects
%Maximize figure window for easy viewing
figure7 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure7,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

% NOTE: bwboundaries() returns a cell array, where each cell contains the row/column coordinates for an object in the image.
% Plot the borders of all the objects on the original grayscale image using the coordinates returned by bwboundaries.
figure(7),imshow(Ione);
axis image; % Make sure image is not artificially stretched because of screen's aspect ratio.
hold on;

boundaries = bwboundaries(Ioneedgedfill);
numberOfBoundaries = size(boundaries, 1);
for k = 1 : numberOfObjects
	thisBoundary = boundaries{k};
	plot(thisBoundary(:,2), thisBoundary(:,1), 'g', 'LineWidth', 2);
end
hold off;

for k = 1 : numberOfObjects % Loop through all objects.	
	EyeArea(k) = EyeMeasurements(k).Area; % Get area.
end

%% Step 9: Select final regions and create image mask
allregionAreas = [EyeMeasurements.Area];
allregionAreaindeces = (allregionAreas == max(EyeArea)); %Select max-area object, which should be the eye. If not, change criteria to identify the eye object. 
% Now get actual indeces, rather than logical indeces, of the  features that meet the criteria.
realindeces = find(allregionAreaindeces);
% Extract only the eye object and eliminate objects that don't meet the criteria in allregionAreaindeces.
% Use ismember() to do this.  Result will be an image - the same as labeledImage but with only the Eye listed in keeperindeces.
keeperregionImage = ismember(labeledImage, realindeces);
% Re-label with only the eye kept.
relabeledImage = bwlabel(keeperregionImage, 8);     % Label each Object so we can make measurements of it

%% Step 10: Get parameters, trace boundaries again, label eye after removing any extraneous objects in the image.

tic; %Start timer

EyeMeasurements = regionprops(relabeledImage, Ione, 'Centroid','Area','Perimeter','EquivDiameter'); % 1) Identify centroid of eye, and 2) calculate area, perimeter, and approximate diameter.
numberOfObjects = size(EyeMeasurements, 1);

elapsedtime2 = toc; %Stop timer and record elapsed time

%Maximize figure window for easy viewing
figure7 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure7,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

figure(7),imshow(Ione);
hold on;
boundaries = bwboundaries(relabeledImage);
numberOfBoundaries = size(boundaries, 1);
for k = 1 : numberOfBoundaries
	thisBoundary = boundaries{k};
	plot(thisBoundary(:,2), thisBoundary(:,1), 'black', 'LineWidth', 3);
end
hold off;

textFontSize = 14;	% Used to control size of "Object number" labels put atop the image.
labelShiftX = -7;	% Used to align the labels in the centers of the objects.

EyeArea = EyeMeasurements.Area; % Get area.
EyePerimeter = EyeMeasurements.Perimeter; % Get perimeter.
EyeCentroid = EyeMeasurements.Centroid; % Get centroid one at a time
EquivDiameter = EyeMeasurements.EquivDiameter; % Get Equivalent Circular Diameter.
	
% Label Eye
text(EyeCentroid(1) + labelShiftX, EyeCentroid(2), Eye, 'FontSize', textFontSize, 'FontWeight', 'Bold', 'Color', 'black');

% Save image figure file1
saveas(figure(7),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'Image1']),'fig')

%% Step 11: Define Approximate Eye Center and Pupil Center
%Maximize figure window for easy viewing
figure8 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure8,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

figure(8),imshow(Ione);
hold on;
boundaries = bwboundaries(relabeledImage);
numberOfBoundaries = size(boundaries, 1);
for k = 1 : numberOfBoundaries
	thisBoundary = boundaries{k};
	plot(thisBoundary(:,2), thisBoundary(:,1), 'black', 'LineWidth', 3);
end
hold on;

EyeCenterPosition = EyeMeasurements(1).Centroid;
EyeCenter = drawpoint('Position',EyeCenterPosition);
EyeCenter.Label = 'C';
EyeCenter.Color = 'r';

promptMessage = sprintf('Identify pupil center by: 1) Drawing a line connecting the two sides of the iris, 2) Drag the line to the anterior surface of the lens, staying between the guides, and 3) Single click to finalize position.');
title(promptMessage, 'FontSize', 12);

InitialLine = drawline; %Draw ROI line from one edge of pupil to the other
InitialLinePosition = InitialLine.Position;

%Display guide line 1 at 90 degrees to maintain pupil center position.
x0a = InitialLinePosition(1,1); %center point x coordinate
y0a = InitialLinePosition(1,2); %center point y coordinate
r = 700; %circle radius
teta=-pi:0.01:pi;%circle point increments
xa=r*cos(teta)+x0a;%circle points
ya=r*sin(teta)+y0a;%circle points

% Mark zero-axis 
x1a=r*cos(0)+x0a;
y1a=r*sin(0)+y0a;
zerolineposition(1,1:2) = [x0a y0a];
zerolineposition(2,1:2) = [x1a y1a];
hold on

pupiledgeposition = InitialLinePosition;

% From 'Measure angle at intersection' example, measure reference angle
ab1a = polyfit(zerolineposition(:,1), zerolineposition(:,2), 1);
ab2a = polyfit(pupiledgeposition(:,1), pupiledgeposition(:,2), 1);

vect1a = [1 ab1a(1)]; % create a vector based on the line equation
vect2a = [1 ab2a(1)];
dp = dot(vect1a, vect2a);

% compute vector lengths
length1a = sqrt(sum(vect1a.^2));
length2a = sqrt(sum(vect2a.^2));

% obtain angle of intersection in radians
zeroaxisangle = acos(dp/(length1a*length2a));

% Shift zero-axis of semi-circle by 'zeroaxisangle'
teta=-zeroaxisangle:-0.01:(pi/2); 
xa=r*cos(teta)+x0a;
ya=r*sin(teta)+y0a;

% Plot line at 90 degree angle relative to iris edges
xia=r*cos((pi/2)-(zeroaxisangle))+x0a;
yia=r*sin((pi/2)-(zeroaxisangle))+y0a;
aline = plot([x0a xia],[y0a yia],'black','LineWidth',1.5);

%Display guide line 2 at 90 degrees to maintain pupil center position.
x0b = InitialLinePosition(2,1); %center point x coordinate
y0b = InitialLinePosition(2,2); %center point y coordinate
r = 700; %circle radius
teta=-pi:0.01:pi;%circle point increments
xb=r*cos(teta)+x0b;%circle points
yb=r*sin(teta)+y0b;%circle points

% Mark zero-axis 
x1b=r*cos(pi)+x0b;
y1b=r*sin(pi)+y0b;
zerolineposition(1,1:2) = [x0b y0b];
zerolineposition(2,1:2) = [x1b y1b];
hold on

pupiledgeposition = InitialLinePosition;

% From 'Measure angle at intersection' example, measure reference angle
ab1b = polyfit(zerolineposition(:,1), zerolineposition(:,2), 1);
ab2b = polyfit(pupiledgeposition(:,1), pupiledgeposition(:,2), 1);

vect1b = [1 ab1b(1)]; % create a vector based on the line equation
vect2b = [1 ab2b(1)];
dp = dot(vect1b, vect2b);

% compute vector lengths
length1b = sqrt(sum(vect1b.^2));
length2b = sqrt(sum(vect2b.^2));

% obtain angle of intersection in radians
zeroaxisangle = acos(dp/(length1b*length2b));

% Shift zero-axis of semi-circle by 'zeroaxisangle'
teta=zeroaxisangle:0.01:-(pi/2); 
xb=r*cos(teta)+x0b;
yb=r*sin(teta)+y0b;

% Plot line at 90 degree angle relative to iris edges
xb=r*cos(teta)+x0b;
yb=r*sin(teta)+y0b;

xib=r*cos((pi/2)-(zeroaxisangle))+x0b;
yib=r*sin((pi/2)-(zeroaxisangle))+y0b;
bline = plot([x0b xib],[y0b yib],'black','LineWidth',1.5);

w = waitforbuttonpress;  %This pauses the program, so that you can move line to surface of lens
w = waitforbuttonpress;  %After moving line to lens surface WITH ONE CLICK, click again to label pupil center.
PupilPosition = InitialLine.Position;
PupilCenterPosition = mean(PupilPosition);
PupilCenter = drawpoint('Position',PupilCenterPosition);
PupilCenter.Label = 'P';
PupilCenter.Color = 'r';
delete(InitialLine); %Delete drawn ROI line
delete(aline); %Delete guide line 1
delete(bline); %Delete guide line 2

title([]);

% Save image figure file1
saveas(figure(8),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'Image2']),'fig')

%% Step 12: Divide retina into 7 regions
%Maximize figure window for easy viewing
figure8 = figure('WindowState','maximized',...
    'OuterPosition',[-6.2 238.6 1107.2 588.8]);
% Create axes for maximized figure.
axes1 = axes('Parent',figure8,...
    'Position',[0.102471912041139 0.10008271493825 0.793258426966292 0.859801488833747]);
axis off
hold(axes1,'on');

figure(8)
x0 = EyeCenterPosition(1,1); %center point x coordinate
y0 = EyeCenterPosition(1,2); %center point y coordinate
r = (EyeMeasurements(1).EquivDiameter)/2; %Eye radius
teta=-pi:0.01:pi;%circle point increments
x=r*cos(teta)+x0;%circle points
y=r*sin(teta)+y0;%circle points

% Mark zero-axis 
x1=r*cos(0)+x0;
y1=r*sin(0)+y0;
zerolineposition(1,1:2) = [x0 y0];
zerolineposition(2,1:2) = [x1 y1];
hold on

promptMessage = sprintf('Divide 7 retinal sectors by drawing a line from point C to the RIGHT end of the retina.');
title(promptMessage, 'FontSize', 12);

retinaedge = drawline % Draw line from center to right edge of retina
retinaedgeposition = retinaedge.Position;
delete(retinaedge);

title([]);

% From 'Measure angle at intersection' example, measure reference angle
ab1 = polyfit(zerolineposition(:,1), zerolineposition(:,2), 1);
ab2 = polyfit(retinaedgeposition(:,1), retinaedgeposition(:,2), 1);

vect1 = [1 ab1(1)]; % create a vector based on the line equation
vect2 = [1 ab2(1)];
dp = dot(vect1, vect2);

% compute vector lengths
length1 = sqrt(sum(vect1.^2));
length2 = sqrt(sum(vect2.^2));

% obtain angle of intersection in radians
zeroaxisangle = acos(dp/(length1*length2));

% Shift zero-axis of semi-circle by 'zeroaxisangle'
teta=-zeroaxisangle:-0.01:(-pi-(value)-zeroaxisangle); %-pi-(value) because retina angle from end-to-end is greater than pi by ~(value)
x=r*cos(teta)+x0;
y=r*sin(teta)+y0;
arc=[x;y];
arc=(arc).';
plot(x,y,'black','LineWidth',1.5)
set(gca,'visible','off')
set(gca,'xtick',[])
hold on
axis image 

% Draw semi-circle with n sectors
x=r*cos(teta)+x0;
y=r*sin(teta)+y0;
plot(x,y,'black','LineWidth',1.5)
hold on

n=7;
tet=linspace((-pi-(value)),0,n+1);
xi=r*cos(tet-(zeroaxisangle))+x0;
yi=r*sin(tet-(zeroaxisangle))+y0;
for k=1:numel(xi)
plot([x0 xi(k)],[y0 yi(k)],'black','LineWidth',1.5);
hold on
end

close Figure 9 % This is a blank figure produced as an artifact from maximizing figure windows
close Figure 10 % This is a blank figure produced as an artifact from maximizing figure windows

% Save image figure file1
saveas(figure(8),fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'Image3']),'fig')

% Save workspace
save(fullfile(Genotype,LDcycle,Eye,[Genotype LDcycle Eye 'Workspace']));
